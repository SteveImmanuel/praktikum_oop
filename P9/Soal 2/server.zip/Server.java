interface Server{
	int processRequest(int x);	
}
